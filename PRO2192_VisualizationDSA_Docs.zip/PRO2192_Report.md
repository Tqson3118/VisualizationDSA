GVHD: Thầy NGUYỄN NGHIỆM

Lớp UDPM21 – Nhóm 1

|     |     |     |
| --- | --- | --- |
| Mã  | Họ và tên | Vai trò |
| 1   | Nguyễn Đình Thiên Long | Trưởng nhóm (Full-Stack & Core Engines) |
| 2   | Nguyễn Duy Phương | Thành viên (Frontend Developer) |
| 3   | Võ Hoàng Tú | Thành viên (Backend Developer) |
| 4   | Trần Minh Hiếu | Thành viên (Frontend Developer) |
| 5   | Phạm Minh Hậu | Thành viên (QA Engineer) |
| 6   | Trần Vũ Quang Huy | Thành viên (DevOps & Release Engineer) |

**BÁO CÁO DỰ ÁN TỐT NGHIỆP**

**HỆ THỐNG TRỰC QUAN HÓA CẤU TRÚC DỮ LIỆU, GIẢI THUẬT VÀ NGUYÊN LÝ LẬP TRÌNH CAO CẤP - VISUALIZATIONDSA**

Ngành: Ứng dụng phần mềm

TP.HCM 15-06-2026

TRƯỜNG CAO ĐẲNG THỰC HÀNH FPT

\----- 🕮 -----

**MỤC LỤC**

[LỜI MỞ ĐẦU](#lời-mở-đầu)

[PHẦN 1: GIỚI THIỆU ĐỀ TÀI](#phần-1-giới-thiệu-đề-tài)
- [1.1 Giới thiệu dự án](#11-giới-thiệu-dự-án)
- [1.2 Ban dự án](#12-ban-dự-án)

[PHẦN 2: KHẢO SÁT – SURVEY](#phần-2-khảo-sát--survey)
- [2.1 Yêu cầu của khách hàng](#21-yêu-cầu-của-khách-hàng)
- [2.2 Kế hoạch dự án](#22-kế-hoạch-dự-án)

[PHẦN 3: PHÂN TÍCH - ANALYSIS](#phần-3-phân-tích---analysis)
- [3.1 Mô hình triển khai hệ thống](#31-mô-hình-triển-khai-hệ-thống)
- [3.2 Sơ đồ Use Cases](#32-sơ-đồ-use-cases)
  - [3.2.1 Tổng quan](#321-tổng-quan)
  - [3.2.2 Use Cases dành cho học viên](#322-use-cases-dành-cho-học-viên)
  - [3.2.3 Use Cases dành cho quản trị viên](#323-use-cases-dành-cho-quản-trị-viên)
- [3.3 Đặc tả yêu cầu hệ thống (SRS)](#33-đặc-tả-yêu-cầu-hệ-thống-srs)

[PHẦN 4: THIẾT KẾ - DESIGN](#phần-4-thiết-kế---design)
- [4.1 Mô hình công nghệ](#41-mô-hình-công-nghệ)
- [4.2 Thiết kế giao diện](#42-thiết-kế-giao-diện)
  - [4.2.1 Sitemap](#421-sitemap)
  - [4.2.2 Layout](#422-layout)
  - [4.2.3 Giao diện chức năng](#423-giao-diện-chức-năng)
- [4.3 Thiết kế dữ liệu](#43-thiết-kế-dữ-liệu)
  - [4.3.1 Sơ đồ quan hệ thực thể (ERD)](#431-sơ-đồ-quan-hệ-thực-thể-erd)
  - [4.3.2 Chi tiết thực thể](#432-chi-tiết-thực-thể)
- [4.4 Sơ đồ lớp DAO & Repositories](#44-sơ-đồ-lớp-dao--repositories)

[PHẦN 5: THỰC HIỆN – IMPLEMENT](#phần-5-thực-hiện--implement)
- [5.1 Database DDL](#51-database-ddl)
- [5.2 CSS Layout Glassmorphism](#52-css-layout-glassmorphism)
- [5.3 Sơ đồ kiến trúc công nghệ](#53-sơ-đồ-kiến-trúc-công-nghệ)
- [5.4 Các loại sơ đồ tương tác](#54-các-loại-sơ-đồ-tương-tác)
  - [5.4.1 Sequence Diagram](#541-sequence-diagram)
  - [5.4.2 Activity Diagram](#542-activity-diagram)
- [5.5 API Endpoints](#55-api-endpoints)
  - [5.5.1 Controllers](#551-controllers)
  - [5.5.2 Services (Business Logic Layer)](#552-services-business-logic-layer)

[PHẦN 6: KIỂM THỬ - TESTING](#phần-6-kiểm-thử---testing)

[PHẦN 7: ĐÓNG GÓI & TRIỂN KHAI](#phần-7-đóng-gói--triển-khai)

[KẾT LUẬN & HƯỚNG PHÁT TRIỂN](#kết-luận--hướng-phát-triển)

[TÀI LIỆU THAM KHẢO](#tài-liệu-tham-khảo)

---

# LỜI MỞ ĐẦU

Trong chương trình đào tạo ngành Công nghệ thông tin và Kỹ thuật phần mềm, môn học Cấu trúc dữ liệu & Giải thuật (DSA) và Thiết kế phần mềm (OOP, SOLID, Design Patterns) đóng vai trò nền tảng cốt lõi định hình tư duy lập trình của sinh viên. Tuy nhiên, do tính chất trừu tượng cao của các cấu trúc dữ liệu động (như BST, Đồ thị), các thuật toán đệ quy phức tạp (như Dijkstra, Quick Sort), và các nguyên lý kiến trúc phần mềm, sinh viên thường gặp khó khăn lớn trong việc xây dựng "mô hình ذهني" (mental model) nếu chỉ học qua các slide tĩnh hoặc tài liệu lý thuyết truyền thống.

Dự án **VisualizationDSA** ra đời nhằm giải quyết triệt để rào cản nhận thức này. Bằng cách kết hợp sức mạnh của công nghệ Web hiện đại (Vue 3, Canvas 2D mượt mà 60 FPS) và kiến trúc máy chủ C# .NET Core Clean Architecture, hệ thống cho phép trực quan hóa sinh động các luồng dữ liệu, cho phép tương tác trực tiếp lên giải thuật bằng code tự viết (Monaco Editor), và tích hợp hệ thống kiểm tra checkpoint trắc nghiệm thông minh để sinh viên vừa học lý thuyết vừa thực hành thực tế. Tài liệu này đặc tả chi tiết toàn bộ quá trình khảo sát, phân tích, thiết kế và hiện thực dự án VisualizationDSA qua 12 Sprints phát triển.

---

# PHẦN 1: GIỚI THIỆU ĐỀ TÀI

## 1.1 Giới thiệu dự án

Dự án **VisualizationDSA** là một nền tảng Web tương tác chuyên biệt phục vụ giáo dục, tập trung vào việc mô phỏng trực quan hóa giải thuật cấu trúc dữ liệu và các nguyên lý kỹ nghệ phần mềm nâng cao. 
- **Làm cái gì?** Xây dựng một ứng dụng Single Page Application (SPA) với động cơ Canvas 2D vẽ đồ họa bám tần số quét màn hình (requestAnimationFrame), Monaco Editor biên dịch mã nguồn Client-side qua Web Worker, và một C# ASP.NET Core Web API quản lý người dùng, chấm điểm trắc nghiệm và gamification (XP, badges).
- **Bối cảnh chọn đề tài:** Sự thiếu hụt các công cụ trực quan hóa có tính năng biên dịch mã nguồn của sinh viên (nhập code tùy ý và xem nó chạy từng bước trên cấu trúc dữ liệu) và các công cụ mô phỏng nguyên lý SOLID/OOP hay Call Stack 3D.
- **Đối tượng sử dụng:** Sinh viên ngành Công nghệ phần mềm, giảng viên dạy bộ môn DSA/OOP, và lập trình viên muốn củng cố kiến trúc hệ thống.

## 1.2 Ban dự án

| Họ và tên | Mã sinh viên | Vai trò trong dự án | Nhiệm vụ chính |
| :--- | :---: | :--- | :--- |
| **Nguyễn Đình Thiên Long** | PS12345 | Trưởng nhóm | Thiết kế Core Animation Engine, AST compiler, DB schema & Call Stack 3D |
| **Nguyễn Duy Phương** | PS12346 | Thành viên | Lập trình HTML5 Canvas Renderers, Playground đồ thị & VCR controls |
| **Võ Hoàng Tú** | PS12347 | Thành viên | Xây dựng API Web Services, Authentication JWT, và Concurrency Simulation |
| **Trần Minh Hiếu** | PS12348 | Thành viên | Lập trình Slide System, Quiz Card Overlay, SOLID/DI Container Sandboxes |
| **Phạm Minh Hậu** | PS12349 | Thành viên | Quản lý chất lượng (QA), viết Unit Tests frontend (Vitest) và C# Backend tests |
| **Trần Vũ Quang Huy** | PS12350 | Thành viên | Đóng gói container Docker, tối ưu hóa CSS Glassmorphism, viết tài liệu HDSD |

Dưới đây là hình ảnh các thành viên trong Ban dự án:
<div style="text-align: center; margin: 10px 0;">
  <img src="imgs/avatar_longndt.jpg" alt="Nguyễn Đình Thiên Long" width="14%" style="border-radius: 50%; margin: 5px;" />
  <img src="imgs/avatar_duyphuong.jpg" alt="Nguyễn Duy Phương" width="14%" style="border-radius: 50%; margin: 5px;" />
  <img src="imgs/avatar_hoangtu.jpg" alt="Võ Hoàng Tú" width="14%" style="border-radius: 50%; margin: 5px;" />
  <img src="imgs/avatar_minhhieu.jpg" alt="Trần Minh Hiếu" width="14%" style="border-radius: 50%; margin: 5px;" />
  <img src="imgs/avatar_minhhau.jpg" alt="Phạm Minh Hậu" width="14%" style="border-radius: 50%; margin: 5px;" />
  <img src="imgs/avatar_quanghuy.jpg" alt="Trần Vũ Quang Huy" width="14%" style="border-radius: 50%; margin: 5px;" />
</div>

---

# PHẦN 2: KHẢO SÁT – SURVEY

## 2.1 Yêu cầu của khách hàng

Qua khảo sát thực tế nhu cầu giảng dạy của giáo viên và học tập của sinh viên, hệ thống VisualizationDSA cần đáp ứng các nhóm yêu cầu sau:

### Yêu cầu chức năng (Functional Requirements)
1.  **Học viên (Student):**
    *   Xem thư viện 10 thuật toán cơ bản (Sorting, BFS/DFS, Dijkstra, BST, Stack/Queue).
    *   Điều khiển VCR Playback (Play/Pause, Từng bước Forward/Backward, Seek Bar, Đổi tốc độ).
    *   So sánh song song 2 thuật toán (Side-by-side) trên cùng một bộ dữ liệu đầu vào.
    *   Biên dịch mã nguồn tự do (Monaco IDE) bằng Javascript và xem trực quan hóa thời gian thực.
    *   Sân chơi đồ thị tương tác: click tự vẽ đỉnh, nối cạnh, kéo thả tự động giãn đỉnh bằng lực vật lý.
    *   Bài giảng Slide có Quiz checkpoint: giải thuật tự tạm dừng để sinh viên trả lời câu hỏi trắc nghiệm.
    *   Hệ thống tích lũy XP, thăng hạng cấp độ Neon và nhận huy hiệu (Badges).
    *   Tạo mã nhúng (Embed Iframe Widget) chia sẻ standalone ra các blog bên ngoài.
2.  **Quản trị viên (Admin):**
    *   Quản lý danh sách thuật toán và cấu hình mã giả 4 ngôn ngữ (C++, Java, Python, JS).
    *   Quản lý bộ câu hỏi trắc nghiệm Quiz checkpoints.
    *   Theo dõi bảng xếp hạng tiến độ (Leaderboard) của sinh viên.

### Yêu cầu phi chức năng (Non-Functional Requirements)
*   **Hiệu năng:** Độ trễ render Canvas dưới 15ms (đảm bảo 60 FPS), thời gian biên dịch AST dưới 5ms.
*   **Bảo mật:** Web Worker Sandbox độc lập, giới hạn vòng lặp tối đa 5000 để tránh crash trình duyệt (Infinite Loop).
*   **Tương thích:** Responsive trên mọi màn hình, hỗ trợ mờ kính Slate Dark Mode sang trọng, không chói mắt.
*   **Độ tin cậy:** Giải phóng bộ nhớ GC an toàn, RAM hoạt động máy khách không vượt quá 22MB khi chạy particle.

## 2.2 Kế hoạch dự án

Lộ trình dự án kéo dài 24 tuần (12 Sprints), mỗi Sprint 2 tuần theo mô hình Agile/Scrum:

| Sprint | Thời gian | Trọng tâm công việc | Thành viên phụ trách | Trạng thái |
| :---: | :---: | :--- | :--- | :---: |
| **S1** | 01/01 - 14/01 | Cài đặt Core Animation rAF Engine & AST Compiler | N.Đ.T Long, P.M Hậu | Hoàn thành |
| **S2** | 15/01 - 28/01 | Sắp xếp mảng Bubble/Quick Sort Lerp di chuyển êm ái | N.D Phương, T.V.Q Huy | Hoàn thành |
| **S3** | 29/01 - 11/02 | Đồng bộ dòng mã giả Monaco Editor click-to-snap | N.D Phương, N.Đ.T Long | Hoàn thành |
| **S4** | 12/02 - 25/02 | Slide bài giảng & Quiz checkpoint trắc nghiệm Canvas | T.M Hiếu, P.M Hậu | Hoàn thành |
| **S5** | 26/02 - 11/03 | Sân chơi đồ thị Force-directed (Lực đẩy Coulomb/Hooke) | N.D Phương, V.H Tú | Hoàn thành |
| **S6** | 12/03 - 25/03 | OOP Sandbox trực quan hóa Encapsulation & VTable ảo | N.Đ.T Long, T.M Hiếu | Hoàn thành |
| **S7** | 26/03 - 08/04 | Phân tích SOLID SRP LCOM4 & Hiệu ứng vỡ kính LSP | T.M Hiếu, T.V.Q Huy | Hoàn thành |
| **S8** | 09/04 - 22/04 | DI Container Singleton/Transient & BFS Cycle detection | N.Đ.T Long, P.M Hậu | Hoàn thành |
| **S9** | 23/04 - 06/05 | Observer & Strategy Patterns (phát hạt Neon Bezier) | N.D Phương, V.H Tú | Hoàn thành |
| **S10** | 07/05 - 20/05 | Giám sát Call Stack 3D Memory Stack-to-Heap Bezier | N.Đ.T Long, N.D Phương | Hoàn thành |
| **S11** | 21/05 - 03/06 | Load Balancer bốc khói & DB Replication Lag queue | V.H Tú, T.V.Q Huy | Hoàn thành |
| **S12** | 04/06 - 15/06 | Tích lũy XP, Leaderboard & standalone Iframe Widget | T.M Hiếu, Cả nhóm | Hoàn thành |

---

# PHẦN 3: PHÂN TÍCH - ANALYSIS

## 3.1 Mô hình triển khai hệ thống

Hệ thống được triển khai trên đám mây theo kiến trúc **Client-First** để giảm chi phí máy chủ và mang lại độ phản hồi tức thì cho người dùng:

```
                  +-----------------------------------+
                  |        Trình duyệt Client         |
                  |  (Vue 3 App - Tĩnh lưu ở CDN)     |
                  +-----------------+-----------------+
                                    |
                       Giao thức HTTPS & JWT Auth
                                    |
                                    v
                  +-----------------+-----------------+
                  |       Cloud Server (API)          |
                  |   (C# ASP.NET Core Web API)       |
                  +-----------------+-----------------+
                                    |
                          Cầu nối ADO.NET EF Core
                                    |
                                    v
                  +-----------------+-----------------+
                  |      PostgreSQL Database          |
                  |     (Lưu trữ đám mây Neon)        |
                  +-----------------------------------+
```

<div style="text-align: center; margin: 15px 0;">
  <img src="imgs/deployment_diagram.png" alt="Sơ đồ triển khai hệ thống" width="70%" style="border: 1px solid #ddd; padding: 5px;" />
  <p><i>Hình 3.1: Sơ đồ mô hình triển khai thực tế hệ thống VisualizationDSA</i></p>
</div>

## 3.2 Sơ đồ Use Cases

### 3.2.1 Tổng quan
Hệ thống gồm hai Tác nhân chính: **Học viên (Student)** thực hành giải thuật học tập và **Quản trị viên (Admin)** quản lý dữ liệu.

### 3.2.2 Use Cases dành cho học viên
```mermaid
graph TD
    Student((Học Viên))
    
    Student --> UC_ViewDSA[Xem & điều khiển VCR Giải thuật]
    Student --> UC_Compare[So sánh song song 2 giải thuật]
    Student --> UC_IDE[Viết code tự do trong Monaco IDE]
    Student --> UC_Playground[Tự vẽ đồ thị tự do & Physics]
    Student --> UC_Quiz[Làm Quiz checkpoint tích lũy XP]
    Student --> UC_Embed[Tạo mã nhúng Iframe Widget]
    Student --> UC_SE[Thực hành SOLID/OOP Sandboxes]
```

### 3.2.3 Use Cases dành cho quản trị viên
```mermaid
graph TD
    Admin((Quản Trị Viên))
    
    Admin --> UC_ManageAlgo[Quản lý thư viện giải thuật]
    Admin --> UC_ManageQuiz[Quản lý câu hỏi Quiz]
    Admin --> UC_Leaderboard[Theo dõi Bảng xếp hạng XP]
```

## 3.3 Đặc tả yêu cầu hệ thống (SRS)

Dưới đây là đặc tả chi tiết một số Use Cases hạt nhân của hệ thống:

### UC1: Đăng nhập hệ thống (Auth)
- **Tác nhân:** Học viên / Admin.
- **Dữ liệu vào (Input):** Email, mật khẩu dạng văn bản.
- **Điều kiện tiên quyết:** Tài khoản đã được đăng ký trên cơ sở dữ liệu.
- **Luồng xử lý chính:**
    1. Người dùng nhập Email và Mật khẩu trên giao diện Glassmorphism.
    2. Frontend gửi POST request tới `/api/v1/auth/login`.
    3. Backend nhận, truy vấn người dùng, dùng BCrypt so sánh mã băm mật khẩu.
    4. Nếu khớp, sinh JWT token không trạng thái (stateless) chứa UserID và Role.
    5. Backend phản hồi HTTP 200 kèm JWT và Avatar URL.
    6. Frontend lưu JWT vào LocalStorage, cập nhật `userStore` và chuyển hướng.
- **Dữ liệu ra (Output):** Trạng thái đăng nhập được kích hoạt, lưu trữ JWT thành công.

### UC2: Biên dịch mã nguồn tự do (Monaco IDE)
- **Tác nhân:** Học viên.
- **Dữ liệu vào (Input):** Chuỗi mã nguồn Javascript nhập vào Monaco Editor.
- **Luồng xử lý chính:**
    1. Học viên nhấp nút [Chạy mã].
    2. Trình phân tích cú pháp Acorn quét mã nguồn, dựng cấu trúc cây AST.
    3. Chèn các câu lệnh đệm theo dõi (Trace triggers) vào các phép gán, phép so sánh và loop counter guard.
    4. Khởi tạo một Web Worker Sandbox, truyền mã đã biến đổi vào chạy độc lập.
    5. Web Worker chạy sinh mảng `LiveFrameDTO` (vết bộ nhớ của các phần tử).
    6. Nếu gặp loop vô hạn (>5000 lần), Timeout Guard 1.5s ngắt luồng Worker, báo lỗi.
    7. Trả mảng Frame về UI, nạp vào `useAnimationStore` để Canvas vẽ.
- **Dữ liệu ra (Output):** Hoạt cảnh giải thuật chuyển động sinh động bám sát code tự viết.

---

# PHẦN 4: THIẾT KẾ - DESIGN

## 4.1 Mô hình công nghệ

```
+-----------------------------------------------------------------------------------+
| FRONTEND LAYER (Vue 3 Single Page Application)                                    |
| - Giao diện: Vue 3 Composition API, Vite Bundler, Tailwind/Vanilla CSS             |
| - Trực quan hóa: HTML5 Canvas 2D, SVG Bezier Connector, Physics Engine (Coulomb)  |
| - Trình soạn thảo: Monaco Editor + MonacoGutterClickInterceptor                   |
| - Quản lý trạng thái: Pinia Stores (userStore, vcrStore, algorithmStore)          |
+----------------------------------------+------------------------------------------+
                                         | Kết nối qua HTTPS RESTful API & JWT
                                         v
+-----------------------------------------------------------------------------------+
| BACKEND LAYER (ASP.NET Core C# Clean Architecture)                                |
| - Presentation: ASP.NET Core Web API Controllers, ErrorHandlingMiddleware         |
| - Application: Services (Progress, User, Widget), FluentValidation, DTOs          |
| - Infrastructure: Entity Framework Core ORM, JWT Token Generator, BCrypt Hasher  |
| - Domain: Core Entities (User, UserProgress, Algorithm, Quiz, Achievement)       |
+----------------------------------------+------------------------------------------+
                                         | ADO.NET Connection
                                         v
+-----------------------------------------------------------------------------------+
| DATABASE LAYER                                                                    |
| - PostgreSQL Database (Lưu trữ quan hệ)                                           |
+-----------------------------------------------------------------------------------+
```

## 4.2 Thiết kế giao diện

### 4.2.1 Sitemap
```
Dashboard (Trang chủ chào mừng, tóm lược XP và Badges)
 ├── DSA Modules (Trình phát giải thuật 60 FPS, mã giả Monaco gutter click)
 ├── Code IDE (Sân chơi tự viết code, console biên dịch AST, chạy visualizer)
 ├── Playground (Vẽ đồ thị tương tác chuột, physics forces Coulomb/Hooke)
 ├── So sánh (So sánh song song 2 giải thuật Bubble vs Quick Sort trên cùng mảng)
 ├── Đa luồng (Mô phỏng Deadlock DFS, Dining Philosophers, Mutex locks)
 ├── Sandboxes (OOP VTable Routing, SOLID SRP LCOM4, DI Transient/Singleton)
 └── Embed Widget (Trình cấu hình sinh mã nhúng iframe chia sẻ)
```

<div style="text-align: center; margin: 15px 0;">
  <img src="imgs/sitemap_diagram.png" alt="Sơ đồ Sitemap ứng dụng" width="80%" style="border: 1px solid #ddd; padding: 5px;" />
  <p><i>Hình 4.1: Sơ đồ sitemap phân cấp chức năng của ứng dụng</i></p>
</div>

### 4.2.2 Layout
Bố cục ứng dụng sử dụng thiết kế **Glassmorphic Split-Pane** thời thượng:
- **Thanh bên trái (Navigation Bar):** Panel mờ kính (backdrop-blur-md) màu nền tối Slate, chứa logo Neon và liên kết chuyển trang.
- **Khung chính (Main Content Area):** Chia đôi linh hoạt (Split-Pane):
    - *Pane Trái:* Canvas 2D vẽ đồ họa thuật toán màu HSL Neon tự phát sáng, bên dưới là thanh VCR Control Panel màu ngọc lục bảo (Emerald).
    - *Pane Phải:* Monaco Editor hiển thị mã nguồn và bảng đồng bộ mã giả đa ngôn ngữ, phía dưới cùng là Watch Variables Panel theo dõi biến bộ nhớ.

<div style="text-align: center; margin: 15px 0;">
  <img src="imgs/layout_mockup.png" alt="Bản phác thảo Layout" width="75%" style="border: 1px solid #ddd; padding: 5px;" />
  <p><i>Hình 4.2: Phác thảo Layout chia màn hình (Split-Pane) của VisualizationDSA</i></p>
</div>

### 4.2.3 Giao diện chức năng
Mô tả hoạt động tương tác bảng điều khiển VCR Playback (`VcrControlPanel.vue`):

| TT | Điều khiển | Sự kiện | Mô tả hoạt động |
| :---: | :--- | :--- | :--- |
| 1 | Nút [Play/Pause] | Click / Space | Đảo trạng thái `vcrStore.isPlaying`. Canvas chạy hoặc tạm dừng. |
| 2 | Nút [Replay] | Click | Reset `currentFrame = 0`, khôi phục trạng thái ban đầu của mảng. |
| 3 | Slider Seekbar | Input (Scrub) | Throttled 30 FPS cập nhật vị trí khung hình nhảy trực tiếp đến frame chọn. |
| 4 | Nút [Step Back] | Click / ArrowLeft | Giảm `currentFrame` đi 1 đơn vị nếu giải thuật đang pause. |
| 5 | Nút [Step Fwd] | Click / ArrowRight | Tăng `currentFrame` đi 1 đơn vị. Tô sáng dòng mã giả tương ứng. |
| 6 | Dropdown Speed | Change | Thay đổi tốc độ hiển thị từ 0.25x đến 4.0x, lưu cấu hình vào LocalStorage. |

Dưới đây là hình ảnh chụp giao diện hoạt động thực tế của toàn bộ các phân hệ chức năng trong hệ thống:

<div style="text-align: center; margin: 20px 0;">
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_auth.png" alt="Giao diện đăng nhập" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.3: Giao diện Đăng nhập & Đăng ký tài khoản (Glassmorphism Auth UI)</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_dashboard.png" alt="Giao diện Dashboard" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.4: Giao diện Trang chủ Dashboard (Tổng hợp cấp độ, điểm XP và Lộ trình học)</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_visualizer.png" alt="Giao diện Trực quan hóa giải thuật" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.5: Giao diện Trực quan hóa giải thuật Sắp xếp có VCR điều khiển và đồng bộ mã giả</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_comparison.png" alt="Giao diện So sánh song song" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.6: Giao diện So sánh song song 2 thuật toán trên cùng bộ dữ liệu đầu vào</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_graph_playground.png" alt="Giao diện Sân chơi Đồ thị" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.7: Giao diện Sân chơi Đồ thị tương tác vật lý, co giãn đỉnh bằng lực đẩy Coulomb</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_monaco_ide.png" alt="Giao diện Monaco IDE tự do" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.8: Giao diện Monaco Code IDE tự do, biên dịch mã Javascript sang AST trong Web Worker</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_slide_quiz.png" alt="Giao diện Slide & Quiz" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.9: Giao diện Trình phát Slide bài giảng ngắt mạch làm Quiz trắc nghiệm checkpoint</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_concurrency.png" alt="Giao diện Mô phỏng Đa luồng" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.10: Giao diện trực quan hóa các lỗi Concurrency (Deadlock, Dining Philosophers, Mutex)</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_solid_sandbox.png" alt="Giao diện SOLID Sandboxes" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.11: Giao diện Sandbox thực nghiệm SOLID (Liskov vi phạm nứt kính và SRP LCOM4)</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_embed_widget.png" alt="Giao diện cấu hình Widget" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.12: Trình cấu hình xuất mã nhúng Iframe Standalone chia sẻ giải thuật ra ngoài</i></p>
  </div>
  <div style="margin-bottom: 20px;">
    <img src="imgs/ui_leaderboard.png" alt="Giao diện Bảng xếp hạng" width="85%" style="border: 1px solid #ddd; padding: 5px;" />
    <p><i>Hình 4.13: Trang Hồ sơ cá nhân (Profile) tích lũy Huy hiệu và Bảng xếp hạng Leaderboard nhóm</i></p>
  </div>
</div>

## 4.3 Thiết kế dữ liệu

### 4.3.1 Sơ đồ quan hệ thực thể (ERD)
Lược đồ dữ liệu lưu trữ quan hệ PostgreSQL biểu diễn sự tương tác chặt chẽ của người dùng, tiến trình học tập, quiz và widget nhúng:

```mermaid
erDiagram
    USERS ||--|| USER_PROGRESS : "has progress"
    USERS ||--oN USER_SUBMISSIONS : "submits"
    USERS ||--oN EMBEDDING_WIDGETS : "owns widgets"
    USERS ||--oN USER_CUSTOM_PLAYGROUNDS : "saves playgrounds"
    USERS ||--oN USER_UNLOCKED_ACHIEVEMENTS : "unlocks"
    
    ALGORITHMS ||--oN QUIZZES : "associated with"
    ALGORITHMS ||--oN EMBEDDING_WIDGETS : "visualizes"
    
    QUIZZES ||--oN QUIZ_QUESTIONS : "contains"
    QUIZZES ||--oN USER_SUBMISSIONS : "has submissions"
    
    ACHIEVEMENTS ||--oN USER_UNLOCKED_ACHIEVEMENTS : "earned in"

    USERS {
        VARCHAR_50 id PK
        VARCHAR_100 email UK
        VARCHAR_255 password_hash
        VARCHAR_50 role
        VARCHAR_255 avatar_url
        TIMESTAMP created_at
    }
    USER_PROGRESS {
        VARCHAR_50 id PK
        VARCHAR_50 user_id FK,UK
        INT current_xp
        INT current_level
        INT algorithms_completed
        INT quizzes_completed
    }
    ALGORITHMS {
        VARCHAR_50 id PK
        VARCHAR_100 name
        TEXT description
        VARCHAR_50 category
        VARCHAR_50 complexity_time
        VARCHAR_50 complexity_space
        VARCHAR_30 difficulty
    }
    QUIZZES {
        VARCHAR_50 id PK
        VARCHAR_50 algorithm_id FK
        VARCHAR_150 title
        TEXT instructions_md
        INT max_score
        INT xp_reward
        INT passing_score
        BOOLEAN is_active
    }
    QUIZ_QUESTIONS {
        VARCHAR_50 id PK
        VARCHAR_50 quiz_id FK
        TEXT question_text
        VARCHAR_50 question_type
        JSONB options_json
        TEXT correct_answer
    }
    USER_SUBMISSIONS {
        VARCHAR_50 id PK
        VARCHAR_50 user_id FK
        VARCHAR_50 quiz_id FK
        INT score
        BOOLEAN passed
        INT xp_rewarded
        TEXT submitted_code
        JSONB answers_json
    }
    ACHIEVEMENTS {
        VARCHAR_50 id PK
        VARCHAR_100 name
        TEXT description
        VARCHAR_100 badge_icon_neon
        VARCHAR_50 requirement_type
        INT requirement_value
        INT xp_reward
    }
    USER_UNLOCKED_ACHIEVEMENTS {
        VARCHAR_50 user_id PK,FK
        VARCHAR_50 achievement_id PK,FK
        TIMESTAMP unlocked_at
    }
    EMBEDDING_WIDGETS {
        VARCHAR_50 id PK
        VARCHAR_50 user_id FK
        VARCHAR_50 algorithm_id FK
        VARCHAR_150 title
        VARCHAR_50 theme
        INT width
        INT height
        BOOLEAN allow_interaction
        JSONB custom_data_json
    }
    USER_CUSTOM_PLAYGROUNDS {
        VARCHAR_50 id PK
        VARCHAR_50 user_id FK
        VARCHAR_100 name
        VARCHAR_50 algorithm_type
        JSONB custom_data_json
    }
```

### 4.3.2 Chi tiết thực thể

#### Bảng `users` (Tài khoản người học)
| Tên trường | Kiểu dữ liệu | Khóa | Ràng buộc | Mô tả |
| :--- | :--- | :---: | :--- | :--- |
| `id` | `VARCHAR(50)` | PK | NOT NULL | Định danh UUID của tài khoản |
| `email` | `VARCHAR(100)` | | UNIQUE, NOT NULL | Thư điện tử đăng nhập |
| `password_hash` | `VARCHAR(255)` | | NOT NULL | Mật khẩu mã hóa BCrypt |
| `role` | `VARCHAR(50)` | | NOT NULL, DEFAULT 'STUDENT' | Quyền truy cập: ADMIN, STUDENT |
| `avatar_url` | `VARCHAR(255)` | | NULL | Đường dẫn ảnh đại diện học viên |
| `created_at` | `TIMESTAMP` | | DEFAULT CURRENT_TIMESTAMP | Ngày khởi tạo tài khoản |

#### Bảng `user_progress` (Tiến trình thăng cấp)
| Tên trường | Kiểu dữ liệu | Khóa | Ràng buộc | Mô tả |
| :--- | :--- | :---: | :--- | :--- |
| `id` | `VARCHAR(50)` | PK | NOT NULL | Khóa chính |
| `user_id` | `VARCHAR(50)` | FK | UNIQUE, REFERENCES `users`(id) | Liên kết người dùng |
| `current_xp` | `INT` | | CHECK (`current_xp` >= 0) | Điểm kinh nghiệm neon tích lũy |
| `current_level` | `INT` | | CHECK (`current_level` >= 1) | Cấp bậc neon hiện tại (1-100) |
| `algorithms_completed`| `INT` | | DEFAULT 0 | Tổng giải thuật đã click xem |
| `quizzes_completed` | `INT` | | DEFAULT 0 | Tổng quiz đã pass |

#### Bảng `algorithms` (Danh mục giải thuật)
| Tên trường | Kiểu dữ liệu | Khóa | Ràng buộc | Mô tả |
| :--- | :--- | :---: | :--- | :--- |
| `id` | `VARCHAR(50)` | PK | NOT NULL | Slug định danh (ví dụ: 'dijkstra') |
| `name` | `VARCHAR(100)` | | NOT NULL | Tên giải thuật hiển thị |
| `description` | `TEXT` | | NOT NULL | Mô tả chi tiết nguyên lý |
| `category` | `VARCHAR(50)` | | NOT NULL | Phân mục: SORTING, GRAPH, SOLID... |
| `complexity_time` | `VARCHAR(50)` | | NOT NULL | Độ phức tạp thời gian Big-O |
| `complexity_space`| `VARCHAR(50)` | | NOT NULL | Độ phức tạp không gian Big-O |

#### Bảng `embedding_widgets` (Thông số cấu hình mã nhúng iframe)
| Tên trường | Kiểu dữ liệu | Khóa | Ràng buộc | Mô tả |
| :--- | :--- | :---: | :--- | :--- |
| `id` | `VARCHAR(50)` | PK | NOT NULL | Khóa UUID widget nhúng |
| `user_id` | `VARCHAR(50)` | FK | REFERENCES `users`(id) | Người dùng sở hữu widget |
| `algorithm_id` | `VARCHAR(50)` | FK | REFERENCES `algorithms`(id) | Giải thuật hiển thị trong widget |
| `theme` | `VARCHAR(50)` | | DEFAULT 'GLASS_SLATE_DARK' | Tên giao diện nhúng |
| `width` | `INT` | | CHECK (`width` > 0) | Chiều rộng widget |
| `height` | `INT` | | CHECK (`height` > 0) | Chiều cao widget |
| `custom_data_json`| `JSONB` | | NULL | Chứa thông số đỉnh/cạnh tùy chỉnh |

## 4.4 Sơ đồ lớp DAO & Repositories

Dự án áp dụng mẫu thiết kế **Repository Pattern** cùng với Entity Framework Core DbContext để tối đa hóa tính độc lập của tầng nghiệp vụ đối với cơ sở dữ liệu. Dưới đây là sơ đồ lớp biểu diễn cấu trúc kết nối dữ liệu:

```mermaid
classDiagram
    class ApplicationDbContext {
        +DbSet~User~ Users
        +DbSet~UserProgress~ UserProgresses
        +DbSet~Algorithm~ Algorithms
        +DbSet~EmbeddingWidget~ EmbeddingWidgets
        +SaveChangesAsync() Task~int~
    }
    class IApplicationDbContext {
        <<interface>>
        +DbSet~User~ Users
        +DbSet~UserProgress~ UserProgresses
        +DbSet~Algorithm~ Algorithms
        +DbSet~EmbeddingWidget~ EmbeddingWidgets
        +SaveChangesAsync() Task~int~
    }
    IApplicationDbContext <|.. ApplicationDbContext
    
    class IUserRepository {
        <<interface>>
        +GetByIdAsync(string id) Task~User~
        +GetByEmailAsync(string email) Task~User~
        +AddAsync(User user) Task
    }
    class UserRepository {
        -ApplicationDbContext _context
        +GetByIdAsync(string id) Task~User~
        +GetByEmailAsync(string email) Task~User~
        +AddAsync(User user) Task
    }
    IUserRepository <|.. UserRepository
    UserRepository --> ApplicationDbContext : uses
```

---

# PHẦN 5: THỰC HIỆN – IMPLEMENT

## 5.1 Database DDL

Dưới đây là một phần mã lệnh SQL DDL chính xác để khởi tạo cấu trúc cơ sở dữ liệu PostgreSQL của hệ thống VisualizationDSA:

```sql
-- Tạo bảng Users
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'STUDENT',
    avatar_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tạo bảng User Progress
CREATE TABLE user_progress (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    current_xp INT NOT NULL DEFAULT 0 CHECK (current_xp >= 0),
    current_level INT NOT NULL DEFAULT 1 CHECK (current_level >= 1),
    algorithms_completed INT NOT NULL DEFAULT 0,
    quizzes_completed INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tạo bảng Algorithms
CREATE TABLE algorithms (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    complexity_time VARCHAR(50) NOT NULL,
    complexity_space VARCHAR(50) NOT NULL,
    difficulty VARCHAR(30) NOT NULL CHECK (difficulty IN ('EASY', 'MEDIUM', 'HARD')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tạo bảng Embedding Widgets
CREATE TABLE embedding_widgets (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) REFERENCES users(id) ON DELETE CASCADE,
    algorithm_id VARCHAR(50) NOT NULL REFERENCES algorithms(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    theme VARCHAR(50) NOT NULL DEFAULT 'GLASS_SLATE_DARK',
    width INT NOT NULL CHECK (width >= 300 AND width <= 1920),
    height INT NOT NULL CHECK (height >= 300 AND height <= 1200),
    allow_interaction BOOLEAN NOT NULL DEFAULT TRUE,
    custom_data_json JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 5.2 CSS Layout Glassmorphism

Tệp CSS toàn cục `style.css` thiết lập ngôn ngữ thiết kế **Glassmorphism mờ kính** kết hợp viền sáng Neon HSL sắc nét của ứng dụng:

```css
:root {
  /* Neon Palette HSL Variables */
  --neon-cyan: 190 100% 50%;
  --neon-emerald: 150 100% 43%;
  --neon-amber: 35 100% 55%;
  --neon-crimson: 345 100% 50%;
  --slate-dark: 220 25% 10%;
  --slate-panel: 222 20% 14%;
}

/* Glassmorphic Panel Container */
.glass-panel {
  background: rgba(20, 24, 33, 0.65);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
  border-radius: 12px;
}

/* Active Neon Glow Accent Class */
.neon-glow-cyan {
  border-color: hsl(var(--neon-cyan));
  box-shadow: 0 0 15px rgba(0, 229, 255, 0.25),
              inset 0 0 10px rgba(0, 229, 255, 0.1);
  text-shadow: 0 0 8px hsl(var(--neon-cyan) / 0.5);
}

.neon-glow-emerald {
  border-color: hsl(var(--neon-emerald));
  box-shadow: 0 0 15px rgba(0, 230, 118, 0.25),
              inset 0 0 10px rgba(0, 230, 118, 0.1);
}
```

## 5.3 Sơ đồ kiến trúc công nghệ

Cơ cấu tổ chức thư mục của dự án theo sát mô hình phát triển sạch phân rã nghiệp vụ:

### Cấu trúc Frontend (Vue 3 + Vite + TypeScript)
```
frontend/
├── index.html                  # Gốc tải ứng dụng SPA
├── vite.config.ts              # Cấu hình bundler Vite & Split Chunks
├── src/
│   ├── main.ts                 # Khởi tạo Vue app, Router & Pinia Store
│   ├── style.css               # CSS biến màu HSL Neon & Glassmorphism
│   ├── App.vue                 # Component mẹ bọc bố cục layout chia pane
│   ├── store/                  # Quản lý Pinia Stores
│   │   ├── userStore.ts        # Lưu JWT token & XP
│   │   ├── vcrStore.ts         # Quản lý timeline VCR điều khiển
│   │   └── algorithmStore.ts   # Mã nguồn Monaco & AST snapshots
│   ├── components/             # Các khối giao diện dùng chung
│   │   ├── AlgorithmCanvas.vue # HTML5 Canvas 2D vẽ đồ họa Lerp
│   │   └── CodeEditor.vue      # Monaco editor bọc tùy biến
│   └── core/                   # Logic thuật toán xử lý client-side
│       ├── CoreAnimationEngine.ts  # Động cơ requestAnimationFrame
│       └── CompilerStepExecutor.ts # Phân tích AST sinh snapshots
```

### Cấu trúc C# Backend (Clean Architecture)
```
backend/src/
├── VisualizationDSA.Domain/             # Tầng Domain chứa các thực thể Entity
│   └── Entities/ (User.cs, UserProgress.cs, Algorithm.cs, EmbeddingWidget.cs)
├── VisualizationDSA.Application/        # Tầng ứng dụng chứa Services nghiệp vụ
│   ├── Interfaces/ (IUserService.cs, IProgressService.cs, IWidgetService.cs)
│   ├── DTOs/ (AuthDto.cs, ProgressDto.cs, WidgetDto.cs)
│   └── Services/ (UserService.cs, ProgressService.cs, WidgetService.cs)
├── VisualizationDSA.Infrastructure/     # Tầng hạ tầng cấu hình DB & Security
│   ├── Persistence/ (ApplicationDbContext.cs, ApplicationDbContextSeed.cs)
│   └── Security/ (PasswordHasher.cs, JwtTokenGenerator.cs)
└── VisualizationDSA.WebApi/             # Tầng API Endpoints & Middlewares
    ├── Program.cs                       # Khởi động dịch vụ & DI registration
    ├── Controllers/ (AuthController.cs, ProgressController.cs, WidgetController.cs)
    └── Middlewares/ (ErrorHandlingMiddleware.cs)
```

## 5.4 Các loại sơ đồ tương tác

### 5.4.1 Sequence Diagram: Quy trình biên dịch và chạy trực quan code tự viết (Monaco compilation flow)
```mermaid
sequenceDiagram
    autonumber
    actor Student as Học Viên
    participant Editor as Monaco Editor
    participant Compiler as AST Compiler (Acorn)
    participant Worker as Web Worker Sandbox
    participant Store as useAnimationStore
    participant Canvas as HTML5 Canvas 2D
    
    Student->>Editor: Nhập mã JS & click [Run Code]
    Editor->>Compiler: Chuyển mã nguồn dạng chuỗi
    Compiler->>Compiler: Phân tích AST, chèn Loop Guards & Trace Triggers
    alt Lỗi Cú Pháp
        Compiler-->>Editor: Trả về lỗi Syntax Error (Tô đỏ dòng lỗi)
    else Hợp lệ
        Compiler->>Worker: Khởi chạy mã nguồn trong Sandbox
        activate Worker
        Note over Worker: Đếm số vòng lặp loopCounter
        alt Vòng lặp vô hạn (>5000)
            Worker-->>Compiler: Ngắt luồng (Timeout Guard 1.5s)
            Compiler-->>Editor: Báo lỗi vòng lặp vô hạn
        else Chạy thành công
            Worker->>Worker: Tạo danh sách LiveFrameDTO (So sánh, Hoán vị)
            Worker-->>Compiler: Trả về kết quả chuỗi frame JSON
        end
        deactivate Worker
        Compiler->>Store: loadResult() chuyển thành FrameDTO
        loop Tần số 60 FPS (rAF)
            Store->>Canvas: Lấy dữ liệu Frame hiện tại
            Canvas->>Canvas: Vẽ Lerp tọa độ phần tử lên offscreen buffer
            Canvas-->>Student: Hiển thị hoạt cảnh mượt mà
        end
    end
```

### 5.4.2 Activity Diagram: Quy trình trả lời câu hỏi trắc nghiệm Checkpoint (Quiz checkpoints flowchart)
```mermaid
stateDiagram-v2
    [*] --> PlayAlgorithm : VCR chạy giải thuật
    PlayAlgorithm --> DetectCheckpoint : Theo dõi currentIndex
    DetectCheckpoint --> PausePlayback : Phát hiện frame trùng checkpoint
    state PausePlayback {
        [*] --> LockUI : Khóa các nút điều khiển VCR
        LockUI --> ShowQuizOverlay : Hiển thị bảng câu hỏi trắc nghiệm
    }
    ShowQuizOverlay --> SelectAnswer : Học viên chọn đáp án
    state CheckAnswer <<choice>>
    SelectAnswer --> CheckAnswer
    CheckAnswer --> CorrectResponse : Đáp án ĐÚNG
    CheckAnswer --> IncorrectResponse : Đáp án SAI
    CorrectResponse --> PlaySoundAndGlow : Phát âm success + Glow Emerald + Cộng 100 XP
    IncorrectResponse --> ShakeWindow : Shake đỏ Rose + Giải thích đáp án
    ShakeWindow --> SelectAnswer : Chọn lại
    PlaySoundAndGlow --> UnlockUI : Nhấp [Tiếp tục] để mở khóa
    UnlockUI --> ResumePlayback : Tự động chạy tiếp giải thuật
    ResumePlayback --> [*]
```

### 5.4.3 Class Diagram: Cấu trúc lớp động cơ hoạt ảnh và trình biên dịch AST
Dưới đây là sơ đồ lớp biểu diễn cấu trúc của các module xử lý chính trên Client-side bao gồm Động cơ hoạt ảnh 60 FPS, Trình biên dịch mã nguồn và Kho lưu trữ trạng thái Pinia:

```mermaid
classDiagram
    class CoreAnimationEngine {
        -int _animationFrameId
        -double _lastTickTime
        -double _speedMultiplier
        +startLoop() void
        +stopLoop() void
        +tick(double timestamp) void
    }
    class CompilerStepExecutor {
        -string _rawCode
        -AcornParser _parser
        +compileToAST() ASTNode
        +instrumentCode(ASTNode ast) string
        +executeInSandbox(string code) List~LiveFrameDTO~
    }
    class useAnimationStore {
        +List~LiveFrameDTO~ frames
        +int currentFrameIndex
        +bool isPlaying
        +loadResult(List~LiveFrameDTO~ result) void
        +nextFrame() void
        +prevFrame() void
    }
    CoreAnimationEngine --> useAnimationStore : updates/reads
    CompilerStepExecutor --> useAnimationStore : loads frames
```

## 5.5 API Endpoints

### 5.5.1 Controllers

Các API định tuyến thực tế được phát triển trên backend ASP.NET Core Web API:

| URL | HTTP Method | Bảo mật | Mô tả hoạt động |
| :--- | :---: | :---: | :--- |
| `/api/v1/auth/register` | POST | Không | Đăng ký tài khoản học viên mới |
| `/api/v1/auth/login` | POST | Không | Xác thực email/pass, cấp token JWT |
| `/api/v1/progress` | GET | JWT Auth | Truy cập tiến trình XP, cấp độ của user |
| `/api/v1/progress/leaderboard` | GET | Không | Lấy top 10 học viên có XP cao nhất |
| `/api/v1/algorithms` | GET | Không | Lấy danh sách thuật toán và metadata |
| `/api/v1/quizzes/{id}` | GET | JWT Auth | Tải câu hỏi quiz theo ID thuật toán |
| `/api/v1/quizzes/submit` | POST | JWT Auth | Chấm điểm bài làm và ghi nhận cộng XP |
| `/api/v1/widgets` | POST | JWT Auth | Lưu cấu hình widget nhúng iframe |
| `/api/v1/widgets/{id}` | GET | Không | Tải cấu hình widget độc lập để nhúng |

### 5.5.2 Services (Business Logic Layer)

#### `ProgressService` (Quản lý tiến trình & gamification)
*   **Phương thức:** `Task<ProgressDto> AddXpAsync(string userId, int xpAmount)`
    *   **Tham số:** `userId` (mã người dùng), `xpAmount` (lượng điểm XP cộng thêm).
    *   **Mô tả:** Cộng điểm kinh nghiệm vào DB, kiểm tra xem XP vượt ngưỡng thăng cấp không (công thức tính: $XP_{req} = Level \times 1000$). Nếu thăng hạng, cập nhật `current_level` tăng 1, kiểm tra mở khóa huy hiệu (Achievements) liên quan.
*   **Phương thức:** `Task<IEnumerable<LeaderboardEntryDto>> GetLeaderboardAsync()`
    *   **Mô tả:** Truy xuất dữ liệu tiến trình xếp hạng, sắp xếp giảm dần theo XP để đưa lên Dashboard.

#### `WidgetService` (Quản lý Iframe nhúng)
*   **Phương thức:** `Task<WidgetDto> CreateWidgetConfigAsync(string userId, CreateWidgetCommand command)`
    *   **Tham số:** `userId` (chủ sở hữu), `command` (chứa các thông số cấu hình: theme, width, height, allowInteraction, customData).
    *   **Mô tả:** Khởi tạo cấu hình nhúng, lưu dữ liệu tùy chỉnh đỉnh/cạnh đồ thị dạng JSONB vào PostgreSQL, sinh khóa định danh UUID ngẫu nhiên.

---

# PHẦN 6: KIỂM THỬ - TESTING

Để đảm bảo hệ thống vận hành trơn tru và không xảy ra lỗi hồi quy (regression), dự án đã thực thi kiểm thử 2 cấp độ:
1.  **Unit Tests (Vitest & xUnit):** Kiểm tra logic AST Compiler, ForceDirectedEngine, và ProgressService backend. Kết quả đạt 100% pass trên 1550+ tests frontend và 212 tests backend.
2.  **Manual Testing:** Thực hiện kiểm thử thủ công theo kịch bản đã định dạng sẵn trong file tài liệu [PRO2192_Test cases.md](file:///d:/FPT/Hihi/document/PRO2192_Test%20cases.md).

Tất cả các lỗi phát hiện trong quá trình kiểm thử (như lỗi Proxy của Vue khi xử lý mảng đầu vào IDE, lỗi trùng lặp tham số loop guard) đã được khắc phục hoàn toàn ở phiên bản phân phối cuối cùng.

---

# PHẦN 7: ĐÓNG GÓI & TRIỂN KHAI

Hệ thống được đóng gói thành các container Docker độc lập để triển khai nhanh lên môi trường Cloud (AWS/Azure/Render):

### 1. Đóng gói Frontend
Biên dịch mã nguồn TypeScript thành mã tĩnh tối ưu hóa kích thước (Split Chunks Monaco Editor riêng biệt):
```bash
cd frontend
npm install
npm run build
```
Mã tĩnh sau khi build nằm trong thư mục `/dist` được đẩy lên CDN lưu trữ static web (Vercel hoặc Netlify) để tăng tốc độ tải trang máy khách.

### 2. Đóng gói Container Backend & Cơ sở dữ liệu
Dự án cung cấp tệp cấu hình `docker-compose.yml` tại thư mục gốc để khởi động đồng bộ máy chủ API và DB PostgreSQL chỉ với 1 dòng lệnh:
```yaml
version: '3.8'
services:
  db:
    image: postgres:15-alpine
    container_name: algoview_postgres
    environment:
      POSTGRES_DB: visualization_dsa_db
      POSTGRES_USER: algoview_admin
      POSTGRES_PASSWORD: SecretPassword123
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  webapi:
    build:
      context: ./backend
      dockerfile: src/VisualizationDSA.WebApi/Dockerfile
    container_name: algoview_api
    ports:
      - "5000:80"
    environment:
      - ConnectionStrings__DefaultConnection=Host=db;Database=visualization_dsa_db;Username=algoview_admin;Password=SecretPassword123
    depends_on:
      - db
volumes:
  pgdata:
```
Để chạy hệ thống trên môi trường sản xuất:
```bash
docker-compose up -d --build
```
Dữ liệu khởi tạo mẫu (Seed Data) sẽ tự động chạy thông qua tệp `ApplicationDbContextSeed.cs` để gieo các thuật toán và câu hỏi quiz ngay khi container backend khởi động thành công.

---

# KẾT LUẬN & HƯỚNG PHÁT TRIỂN

### Những gì dự án đã đạt được
1.  **Về mặt học thuật:** Mô phỏng thành công 10 thuật toán cấu trúc dữ liệu kinh điển bằng Canvas 60 FPS mượt mà cùng hệ thống slide bài giảng và quiz checkpoint ngắt mạch thông minh.
2.  **Về mặt kỹ nghệ phần mềm:** Dựng thành công 6 mô-đun trực quan hóa khái niệm nâng cao (SOLID LCOM4, LSP rạn nứt kính, DI Container cycle detection, Call Stack 3D Stack-to-Heap Bezier) mà chưa công cụ học tập nào trên thị trường có.
3.  **Về mặt hạ tầng:** Trình IDE Monaco biên dịch AST an toàn trong Web Worker, hạn chế loop vô hạn bảo vệ RAM khách hàng. Backend Clean Architecture C# bảo mật JWT và cơ chế tạo mã nhúng Widget chia sẻ standalone linh hoạt.

### Hướng phát triển trong tương lai
*   **Phase 3 SDK Standalone:** Đóng gói toàn bộ động cơ vẽ Canvas thành một thư viện SDK siêu nhẹ, dễ dàng nhúng vào bất kỳ nền tảng blog cá nhân hay website dạy học nào khác mà không cần cấu hình phức tạp.
*   **Realtime Collaborative Sandbox:** Tích hợp SignalR để sinh viên có thể cùng vẽ đồ thị, thảo luận code và thi đấu giải thuật trên cùng một phòng trực quan hóa thời gian thực.

---

# PHỤ LỤC

### Phụ lục A: Hướng dẫn cài đặt môi trường và công cụ phát triển
Học viên cần chuẩn bị đầy đủ các công cụ sau trước khi khởi chạy mã nguồn cục bộ:
1. **Docker Desktop:** Phiên bản 24.0+ phục vụ chạy cơ sở dữ liệu PostgreSQL và máy chủ Web API.
2. **Node.js:** Phiên bản LTS 18.0+ để cài đặt dependencies và build SPA Frontend.
3. **.NET SDK:** Phiên bản 8.0 hoặc 9.0 để biên dịch mã nguồn C# và chạy EF Core Migrations nếu phát triển local không qua Docker.
4. **pgAdmin 4:** Công cụ trực quan hóa hỗ trợ truy vấn kiểm tra CSDL PostgreSQL.

### Phụ lục B: Danh sách phím tắt điều khiển (VCR Hotkeys) trên Canvas
Hỗ trợ tương tác nhanh cho học viên khi đang theo dõi luồng giải thuật:
* `Phím cách (Space)` - Play / Pause (Chạy hoặc tạm dừng hoạt cảnh).
* `Mũi tên Trái (ArrowLeft)` - Step Backward (Lùi lại 1 bước giải thuật).
* `Mũi tên Phải (ArrowRight)` - Step Forward (Tiến lên 1 bước giải thuật).
* `Phím Esc` - Replay (Tải lại từ đầu giải thuật).

---

# TÀI LIỆU THAM KHẢO

1.  **Vue 3 Documentation:** https://vuejs.org/guide/introduction.html
2.  **Clean Architecture Principles by Robert C. Martin:** https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html
3.  **Monaco Editor API Reference:** https://microsoft.github.io/monaco-editor/
4.  **Acorn Parser & AST tree structure:** https://github.com/acornjs/acorn
5.  **PostgreSQL JSONB Type Optimization:** https://www.postgresql.org/docs/current/datatype-json.html