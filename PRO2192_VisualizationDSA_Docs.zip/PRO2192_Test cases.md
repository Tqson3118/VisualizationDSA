# Kịch Bản Kiểm Thử Chức Năng - VisualizationDSA (Test Cases)

Tài liệu này đặc tả chi tiết các kịch bản kiểm thử chức năng (Functional Test Cases) của nền tảng **VisualizationDSA** nhằm bảo đảm chất lượng vận hành 60 FPS máy khách, tính an toàn của trình biên dịch Web Worker Sandbox, và độ chính xác của API C# Backend.

| | | | | | |
| | | | | | |
|---|---|---|---|---|---|
| | **CASE** | **CHỨC NĂNG** | **DỮ LIỆU MẪU** | **KẾT QUẢ MONG ĐỢI** | **TÌNH TRẠNG** |
| | **1** | **Xác Thực Người Dùng (Auth)** | | | |
| | 1.1 | Để trống thông tin đăng nhập | Click [Đăng nhập] khi form trống | Hiển thị thông báo yêu cầu nhập đầy đủ Email và Mật khẩu | Đã fix |
| | 1.2 | Kiểm tra định dạng Email | Nhập "longndt@com" hoặc "invalid_mail" | Cảnh báo định dạng email không hợp lệ, chặn submit | Đã fix |
| | 1.3 | Đăng nhập sai thông tin | Email: admin@algoview.com, Pass: 111111 | Hệ thống báo lỗi cụ thể "Mật khẩu không chính xác" | Đã fix |
| | 1.4 | Đăng nhập thành công | Email: longndt@algoview.com, Pass: 123456 | Trả về mã JWT Bearer, chuyển hướng về trang Dashboard | Đã fix |
| | **2** | **Trực Quan Hóa DSA (VCR & Canvas)** | | | |
| | 2.1 | Nút điều khiển VCR Play/Pause | Nhấp nút Play/Pause giải thuật | Trực quan hóa chạy/tạm dừng hoạt cảnh vẽ Lerp trên Canvas | Đã fix |
| | 2.2 | Thay đổi tốc độ VCR | Chọn tốc độ 0.5x, 1.0x, 2.0x, 4.0x | Hoạt cảnh Lerp tăng/giảm tốc độ mượt mà, bám khung hình 60 FPS | Đã fix |
| | 2.3 | Kéo thanh trượt Seekbar | Kéo slider sang vị trí 50% tổng số bước | Canvas nhảy trực tiếp đến frame tương ứng, highlight đúng dòng mã giả | Đã fix |
| | 2.4 | Chuyển đổi ngôn ngữ mã giả | Click tab ngôn ngữ Java/C++/Python | Bản mã giả chuyển ngôn ngữ tức thì, giữ nguyên dòng đang highlight | Đã fix |
| | **3** | **Biên Dịch Code IDE (AST Compiler)** | | | |
| | 3.1 | Biên dịch code sai cú pháp | Code thiếu dấu đóng ngoặc `for (int i=0; i<10; i++ {` | Trình biên dịch Acorn báo lỗi cú pháp, tô đỏ dòng lỗi trong Monaco | Đã fix |
| | 3.2 | Biên dịch thành công | Thuật toán Bubble Sort chuẩn Javascript | Tạo chuỗi LiveFrameDTO thành công, nạp vào Canvas chạy trực quan | Đã fix |
| | 3.3 | Chống vòng lặp vô hạn (Infinite Loop) | Ghi code chứa `while(true)` không dừng | Loop Guard đếm vượt quá 5000 vòng, ngắt Web Worker và báo Timeout | Đã fix |
| | **4** | **Sân Chơi Đồ Thị Tự Do (Playground)** | | | |
| | 4.1 | Thêm nút tròn (Node) trên Canvas | Chọn ADD_NODE, click 3 điểm trên Canvas | Tạo 3 nút tròn nhãn A, B, C phát sáng Neon xanh nước biển | Đã fix |
| | 4.2 | Tạo liên kết nối nút (Edge) | Chọn ADD_EDGE, kéo từ nút A sang nút B | Vẽ đường nối Bezier tiếp xúc chuẩn biên hai nút tròn, hiển thị mũi tên | Đã fix |
| | 4.3 | Động cơ vật lý Coulomb & Hooke | Bật toggle Physics, kéo thả kéo nút A | Các nút xung quanh tự động co giãn đẩy xa nhau tránh đè khít | Đã fix |
| | **5** | **Bài Giảng Slide & Trắc Nghiệm** | | | |
| | 5.1 | Đồng bộ Slide với Visualizer | Nhấp nút "Trang sau" trên Slide bài học | Trình trực quan tự động jumpToFrame() đến bước giải thuật tương ứng | Đã fix |
| | 5.2 | Khóa tương tác khi gặp Checkpoint | Trình VCR chạy đến frame có quiz checkpoint | VCR tự động Pause, khóa tương tác panel, hiển thị bảng QuizOverlay | Đã fix |
| | 5.3 | Chấm điểm Quiz & Cộng điểm XP | Click chọn đáp án đúng trong Quiz | Popup báo chính xác màu Emerald, cộng 100 XP vào userStore, phát âm thanh | Đã fix |
| | **6** | **Mô-đun SOLID & OOP Sandbox** | | | |
| | 6.1 | Đo độ kết dính SRP LCOM4 | Nhập lớp vi phạm SRP LCOM4 | Đồ thị LCOM4 tính bằng BFS chỉ ra 3 thành phần rời rạc, báo vi phạm | Đã fix |
| | 6.2 | Vi phạm thay thế LSP (Liskov) | Click nút vi phạm thay thế LSP | Kích hoạt hạt khói nứt vỡ rạn kính (glass crack animation) màu Amber | Đã fix |
| | 6.3 | DI Container Dependency Cycle | ServiceA phụ thuộc ServiceB, B phụ thuộc A | DFS phát hiện vòng lặp cyclic, tô đỏ đường Bezier và báo lỗi vòng lặp | Đã fix |
| | **7** | **Trình Tạo Mã Nhúng (Embed Widget)** | | | |
| | 7.1 | Sinh mã nhúng Iframe cấu hình | Chọn Dijkstra, theme Glass Slate Dark | Sinh chuỗi `<iframe>` có chứa đầy đủ origin whitelist và script resizer | Đã fix |
| | 7.2 | Sao chép mã nhúng | Click nút [Copy Code] nhúng | Đưa mã nhúng vào clipboard, nút chuyển từ Copy sang Copied màu Emerald | Đã fix |
