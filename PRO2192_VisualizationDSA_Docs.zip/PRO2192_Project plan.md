# 🗓️ Kế hoạch Dự án - VisualizationDSA (Project Plan)

Dưới đây là bảng phân rã các đầu công việc chi tiết của dự án **VisualizationDSA** trong suốt 12 Sprints phát triển (24 tuần), bao gồm thời gian thực hiện, thành viên chịu trách nhiệm chính và trạng thái hoàn thành thực tế của hệ thống.

| TT | CÔNG VIỆC | BẮT ĐẦU | KẾT THÚC | THÀNH VIÊN | TÌNH TRẠNG | GHI CHÚ |
| :--- | :--- | :---: | :---: | :--- | :---: | :--- |
| **1** | **PHÂN TÍCH & THIẾT LẬP NỀN TẢNG (Sprint 1 - 3)** | **01/01/2026** | **15/02/2026** | | **Hoàn thành** | **Phase 1 Foundations** |
| 1.1 | Khảo sát yêu cầu khách hàng & đặc tả SRS | 01/01/2026 | 10/01/2026 | Cả nhóm | Hoàn thành | Hoàn tất tài liệu đặc tả |
| 1.2 | Xây dựng Core Animation Engine rAF & AST Compiler | 11/01/2026 | 25/01/2026 | N.Đ.T. Long | Hoàn thành | Logic chạy khung hình 60 FPS |
| 1.3 | Thiết kế lược đồ CSDL PostgreSQL & API Specs | 26/01/2026 | 05/02/2026 | V.H. Tú | Hoàn thành | Hoàn thành file database.md & api-spec.md |
| 1.4 | Lập trình Monaco Editor Sync & Array Visualizer | 06/02/2026 | 15/02/2026 | N.D. Phương | Hoàn thành | Gắn kết gutter click & highlight dòng code |
| **2** | **PHÁT TRIỂN DSA & BÀI GIẢNG TƯƠNG TÁC (Sprint 4 - 6)** | **16/02/2026** | **31/03/2026** | | **Hoàn thành** | **DSA Modules & E-Lecture** |
| 2.1 | Hiện thực E-Lecture Mode & Slide System | 16/02/2026 | 28/02/2026 | T.M. Hiếu | Hoàn thành | Tích hợp slide lý thuyết và trắc nghiệm |
| 2.2 | Xây dựng Graph Playground & Force-Directed Simulation | 01/03/2026 | 15/03/2026 | N.D. Phương | Hoàn thành | Động cơ vật lý Coulomb & Hooke co giãn |
| 2.3 | Hiện thực OOP Sandbox & VTable dynamic dispatch | 16/03/2026 | 31/03/2026 | N.Đ.T. Long | Hoàn thành | Trực quan hóa Encapsulation & Polymorphism |
| **3** | **PHÁT TRIỂN SANDBOX KỸ NGHỆ NÂNG CAO (Sprint 7 - 9)** | **01/04/2026** | **15/05/2026** | | **Hoàn thành** | **Advanced SE Sandboxes** |
| 3.1 | Phân tích SOLID SRP LCOM4 & LSP glass fracture | 01/04/2026 | 15/04/2026 | T.M. Hiếu | Hoàn thành | Tính toán kết dính DFS và hiệu ứng vỡ kính |
| 3.2 | Thiết lập DI Container loop-detection & Bezier Graph | 16/04/2026 | 30/04/2026 | N.Đ.T. Long | Hoàn thành | Minh họa Singleton/Transient & phát hiện vòng lặp |
| 3.3 | Thiết lập Design Patterns Observer & Strategy | 01/05/2026 | 15/05/2026 | N.D. Phương | Hoàn thành | Emitter phát hạt neon uốn cong Bezier nét đứt |
| **4** | **TÍCH HỢP HỆ THỐNG & ĐA LUỒNG (Sprint 10 - 12)** | **16/05/2026** | **15/06/2026** | | **Hoàn thành** | **System Engine & SaaS Widgets** |
| 4.1 | Thiết kế Call Stack 3D Memory Stack-to-Heap | 16/05/2026 | 25/05/2026 | N.Đ.T. Long | Hoàn thành | Theo dõi luồng hàm và con trỏ Heap Bezier |
| 4.2 | Xây dựng Concurrency Visualizer & Load Balancer smoke | 26/05/2026 | 05/06/2026 | V.H. Tú | Hoàn thành | Mô phỏng Deadlock, Round-Robin và hạt khói 2D |
| 4.3 | Tích lũy điểm XP, Badges & Iframe Embed Widget | 06/06/2026 | 15/06/2026 | T.M. Hiếu | Hoàn thành | Gamification và trình tạo mã nhúng standalone |
| **5** | **KIỂM THỬ, ĐÓNG GÓI & TRIỂN KHAI** | **01/01/2026** | **15/06/2026** | | **Hoàn thành** | **Quality Assurance & DevOps** |
| 5.1 | Xây dựng kịch bản kiểm thử tự động (Unit / E2E) | 01/01/2026 | 12/06/2026 | P.M. Hậu | Hoàn thành | 1550+ tests frontend & 212 tests C# backend |
| 5.2 | Lập trình sửa lỗi rò rỉ bộ nhớ, tối ưu hóa FPS | 06/06/2026 | 13/06/2026 | P.M. Hậu | Hoàn thành | Giải phóng GC, ổn định RAM máy khách 15-22MB |
| 5.3 | Đóng gói sản phẩm Docker & viết HDSD | 10/06/2026 | 15/06/2026 | T.V.Q. Huy | Hoàn thành | Đóng gói docker-compose.yml và tài liệu HDSD |
